# create class and implement methods for policy holder
class Policyholder:
    def __init__(self, name, policy_number, is_active=True):
        self.name = name
        self.policy_number = policy_number
        self.is_active = is_active
        self.payments = []

    def register(self):
        self.is_active = True
        print(f"Policyholder {self.name} has been registered.")

    def suspend(self):
        self.is_active = False
        print(f"Policyholder {self.name}'s policy has been suspended.")

    def reactivate(self):
        self.is_active = True
        print(f"Policyholder {self.name}'s policy has been reactivated.")

    def add_payment(self, payment):
        self.payments.append(payment)

    def display_account(self):
        status = "active" if self.is_active else "suspended"
        print(f"Policyholder: {self.name}")
        print(f"Policy Number: {self.policy_number}")
        print(f"Status: {status}")
        for payment in self.payments:
            payment.display_payment()
