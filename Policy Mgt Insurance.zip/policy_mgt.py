# create policyholders who have made payment and display their details
from policyholder import Policyholder
from product import Product
from payment import Payment

# Create two products
product_1 = Product("Life Insurance", "P001", 500000)
product_2 = Product("Auto Insurance", "P002", 200000)

# Create policyholders
policyholder_1 = Policyholder("Babatunde Salman", "H0812")
policyholder_2 = Policyholder("Raphael Wanjiku", "H1972")

# Register policyholders
policyholder_1.register()
policyholder_2.register()

# Create payments
payment_1 = Payment(500000, "2024-12-08")
payment_2 = Payment(200000, "2024-12-13")

# Process payments
payment_1.process_payment()
payment_2.process_payment()

# Add payments to policyholders
policyholder_1.add_payment(payment_1)
policyholder_2.add_payment(payment_2)

# Display account details for policyholders
policyholder_1.display_account()
policyholder_2.display_account()

# Suspend a product
product_1.suspend()

# Display product details
product_1.display_product()
product_2.display_product()

# Suspend policyholder 2
policyholder_2.suspend()
policyholder_2.display_account()
