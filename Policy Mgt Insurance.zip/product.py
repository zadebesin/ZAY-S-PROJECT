# Create class and implement methods for product
class Product:
    def __init__(self, name, product_code, price):
        self.name = name
        self.product_code = product_code
        self.price = price
        self.is_available = True

    def create(self):
        self.is_available = True
        print(f"Product {self.name} has been created.")

    def update(self, new_name, new_price):
        self.name = new_name
        self.price = new_price
        print(f"Product {self.name} has been updated.")

    def suspend(self):
        self.is_available = False
        print(f"Product {self.name} has been suspended.")

    def display_product(self):
        status = "available" if self.is_available else "suspended"
        print(f"Product: {self.name}")
        print(f"Product Code: {self.product_code}")
        print(f"Price: ${self.price}")
        print(f"Status: {status}")
