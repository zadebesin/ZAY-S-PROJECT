# create class and implement method for payment
class Payment:
    def __init__(self, amount, payment_date, is_processed=False):
        self.amount = amount
        self.payment_date = payment_date
        self.is_processed = is_processed

    def process_payment(self):
        self.is_processed = True
        print(f"Payment of ${self.amount} processed on {self.payment_date}.")

    def reminder(self):
        if not self.is_processed:
            print(f"Reminder: Payment of ${self.amount} is pending.")

    def penalty(self):
        if not self.is_processed:
            penalty_amount = self.amount * 0.1  # 10% penalty for missed payment
            print(f"Penalty: ${penalty_amount} for late payment of ${self.amount}.")

    def display_payment(self):
        status = "Processed" if self.is_processed else "Pending"
        print(f"Amount: ${self.amount}")
        print(f"Payment Date: {self.payment_date}")
        print(f"Status: {status}")
