# Task 6: Unzip and Display Data with R

# Specify the path to the ZIP file
zip_file <- "Employee_Profile.zip"

# Check if the ZIP file exists
if (file.exists(zip_file)) {
    # Unzip the folder into 'Employee_Profile' directory
    unzip(zip_file, exdir = "Employee_Profile")
    
    # List the files in the 'Employee_Profile' folder to verify the contents
    file_list <- list.files("Employee_Profile")
    print(file_list)
    
    # Make sure the CSV file exists in the folder
    if (length(file_list) > 0) {
        csv_file <- file.path("Employee_Profile", "Albert Pardini_details.csv")
        
        # Check if the CSV file exists
        if (file.exists(csv_file)) {
            # Read the CSV file into a data frame
            employee_data <- read.csv(csv_file)
            
            # Display the data
            print(employee_data)
        } else {
            print("CSV file not found in the extracted folder.")
        }
    } else {
        print("No files found in the 'Employee_Profile' directory.")
    }
} else {
    print("The ZIP file does not exist in the current directory.")
}
