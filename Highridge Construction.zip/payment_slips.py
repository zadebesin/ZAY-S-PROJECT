import random

# Generate a list of 400 workers 
workers = []
for i in range(400):
    worker = {
        "name": f"Worker {i+1}",
        "salary": random.randint(5000, 35000),  # Random salary between 5000 and 35000
        "gender": random.choice(["Male", "Female"])  # Random gender
    }
    workers.append(worker)

# Function to generate payment slips
def generate_payment_slip(worker):
    try:
        # Extract worker information
        name = worker["name"]
        salary = worker["salary"]
        gender = worker["gender"]

        # Determine employee level based on conditions
        if 10000 < salary < 20000:
            level = "A1"
        elif 7500 < salary < 30000 and gender == "Female":
            level = "A5-F"
        else:
            level = "Not Assigned"

        # Payment slip format
        payment_slip = f"Name: {name}\nSalary: ${salary}\nLevel: {level}\n"
        return payment_slip
    except KeyError as e:
        print(f"Error: Missing key {e} for worker {worker['name']}")
    except Exception as e:
        print(f"An unexpected error occurred for worker {worker['name']}: {str(e)}")

# Generate payment slips for each worker
for worker in workers:
    slip = generate_payment_slip(worker)
    print(slip)
    print("-" * 40)  # Separator between payment slips

