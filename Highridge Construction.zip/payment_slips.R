# Generate a list of 400 workers
workers <- data.frame(
  name = paste("Worker", 1:400),
  salary = sample(5000:35000, 400, replace = TRUE),  # Random salary between 5000 and 35000
  gender = sample(c("Male", "Female"), 400, replace = TRUE)  # Random gender
)

# Function to generate payment slips
generate_payment_slip <- function(worker) {
  tryCatch({
    # Extract worker information
    name <- worker$name
    salary <- worker$salary
    gender <- worker$gender

    # Determine employee level based on conditions
    if (salary > 10000 && salary < 20000) {
      level <- "A1"
    } else if (salary > 7500 && salary < 30000 && gender == "Female") {
      level <- "A5-F"
    } else {
      level <- "Not Assigned"
    }

    # Payment slip format
    payment_slip <- paste("Name:", name, "\nSalary: $", salary, "\nLevel:", level, "\n", sep = " ")
    return(payment_slip)
  }, error = function(e) {
    message(paste("Error:", e$message, "for worker", worker$name))
  })
}

# Generate payment slips for each worker
for (i in 1:nrow(workers)) {
  worker <- workers[i, ]
  slip <- generate_payment_slip(worker)
  cat(slip, "\n", strrep("-", 40), "\n")  # Print payment slip and separator
}